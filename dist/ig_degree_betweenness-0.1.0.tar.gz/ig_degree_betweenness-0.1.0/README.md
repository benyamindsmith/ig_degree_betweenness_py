# ig_degree_betweenness_py

Python implementation of the `ig.degree.betweenness` R package.


```sh
# for an undirected graph (default)
$ python your_script.py my_edges.txt

# for a directed graph
$ python your_script.py -d my_edges.txt

```