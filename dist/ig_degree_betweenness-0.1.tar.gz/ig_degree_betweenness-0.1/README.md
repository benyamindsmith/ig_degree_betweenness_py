# ig_degree_betweenness_py

Python implemmentation of the `ig.degree.betweenness` R package.

Following this [FreeCodeCamp Tutorial](https://www.freecodecamp.org/news/build-your-first-python-package/) on how to package the code. 
